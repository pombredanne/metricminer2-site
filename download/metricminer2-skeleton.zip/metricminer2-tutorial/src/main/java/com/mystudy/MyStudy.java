package com.mystudy;
import br.com.metricminer2.MetricMiner2;
import br.com.metricminer2.Study;

public class MyStudy implements Study {

	public static void main(String[] args) {
		new MetricMiner2().start(new MyStudy());
	}

	@Override
	public void execute() {
		// do the magic here! ;)
	}
}
